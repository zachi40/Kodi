# -*- coding: utf-8 -*-
# Module: default
# Author: zahi ohana
# Created on: 23.05.2016

import urllib, urllib2, re, sys, xbmcplugin, xbmcgui
_handle=int(sys.argv[1])
PluginName="Url Movies"
arrow="arrow/"
nekoda="../"
def read_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB;'
                   ' rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link
        
link = read_url('http://dl.hastidownload.info/1/')
matchs = re.compile('(?<=href=").*?(?=")').findall(link)
if len(matchs) > 0:
	for match in matchs:
		if nekoda in match:
			print ""
		elif arrow in match:
			print ""
		else:
			url="http://dl.hastidownload.info/1/"+match
			item = xbmcgui.ListItem(label=match)
			xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
else :
    xbmcgui.Dialog().ok(PluginName,"No File Was Found")			
    
xbmcplugin.endOfDirectory(_handle)