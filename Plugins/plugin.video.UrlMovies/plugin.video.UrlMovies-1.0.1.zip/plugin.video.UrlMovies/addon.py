# -*- coding: utf-8 -*-
# Module: default
# Author: zahi ohana
# Created on: 23.05.2016

import urllib, urllib2, re, sys, os, xbmcplugin, xbmcgui
from difflib import Match
_handle=int(sys.argv[1])
from resources.lib.profile import *

PluginName="Url Movies"
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.UrlMovies/resources/img', ''))


def links():
 link = read_url('http://dl.hastidownload.info/1/')
 matchs = re.compile('(?<=href=").*?(?=")').findall(link)
 if len(matchs) > 0:
  	videos=matchs
 return videos    

def main_menu(): 
  addDir('0-9',1,art+'0-9.png')
  addDir('A',2,art+'a.png')
  addDir('B',3,art+'b.png')
  addDir('C',4,art+'c.png')
  addDir('D',5,art+'d.png')
  addDir('E',6,art+'e.png')
  addDir('F',7,art+'f.png')
  addDir('G',8,art+'g.png')
  addDir('H',9,art+'h.png')
  addDir('I',10,art+'i.png')
  addDir('J',11,art+'j.png')
  addDir('K',12,art+'k.png')
  addDir('L',13,art+'l.png')
  addDir('M',14,art+'m.png')
  addDir('N',15,art+'n.png')
  addDir('O',16,art+'o.png')
  addDir('P',17,art+'p.png')
  addDir('Q',18,art+'q.png')
  addDir('R',19,art+'r.png')
  addDir('S',20,art+'s.png')
  addDir('T',21,art+'t.png')
  addDir('U',22,art+'u.png')
  addDir('V',23,art+'v.png')
  addDir('W',24,art+'w.png')
  addDir('X',25,art+'x.png')
  addDir('Y',26,art+'y.png')
  addDir('Z',27,art+'z.png')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

params=get_params()
mode=None

try: mode=int(params["mode"])
except:
    try: 
        mode=params["mode"]
    except: pass

 

if mode == None:
    main_menu()
elif  mode == 1:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="0" or chcek =="1" or chcek =="2" or chcek =="3" or chcek =="4" or chcek =="5" or chcek =="6" or chcek =="7"or chcek =="8" or chcek =="9" or chcek =="10":
            url="http://dl.hastidownload.info/1/"+video
            item = xbmcgui.ListItem(label=video)
            xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0) 
           
elif  mode == 2:
    urls=links()
    for video in urls:
            if video =="arrow/" :
                print video
            else :
                chcek=video[0][0]
                if chcek=="A" or chcek =="a":
                    url="http://dl.hastidownload.info/1/"+video
                    item = xbmcgui.ListItem(label=video)
                    xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
elif  mode == 3:
    urls=links()
    for video in urls:
            if video =="bishtar.png" :
                print video
            else :
                chcek=video[0][0]
                if chcek=="B" or chcek =="b":
                    url="http://dl.hastidownload.info/1/"+video
                    item = xbmcgui.ListItem(label=video)
                    xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 4:
    urls=links()
    for video in urls:
            if video =="Clash-of-Clans-8.67.3.apk" or  video =="Clash-of-Clans_8.67.3.apk" or video=="Clash.of.Clans.7.200.12.apk" or video=="Clash.of.Clans.7.200.12.zip" or video=="contextual-related-posts.zip" :
                print " "
            else :
                chcek=video[0][0]
                if chcek=="C" or chcek =="c":
                    url="http://dl.hastidownload.info/1/"+video
                    item = xbmcgui.ListItem(label=video)
                    xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 5:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="D" or chcek =="d":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 6:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="E" or chcek =="e":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 7:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="F" or chcek =="f":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 8:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="G" or chcek =="g":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 9:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="H" or chcek =="h":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 10:
    urls=links()
    for video in urls:
            if video =="iphone6-3g.jpg" :
                print " "
            else :
                chcek=video[0][0]
                if chcek=="I" or chcek =="i":
                    url="http://dl.hastidownload.info/1/"+video
                    item = xbmcgui.ListItem(label=video)
                    xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 11:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="J" or chcek =="j": 
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
            
elif  mode == 12:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="K" or chcek =="k":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 13:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="L" or chcek =="l":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 14:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="M" or chcek =="m":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 15:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="N" or chcek =="n":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 16:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="O" or chcek =="o":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 17:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="P" or chcek =="p":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 18:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="Q" or chcek =="Q":
            url="http://dl.hastidownload.info/1/"+video
            item = xbmcgui.ListItem(label=video)
            xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)           

elif  mode == 19:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="R" or chcek =="r":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 20:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="S" or chcek =="s":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 21:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="T" or chcek =="t":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 22:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="U" or chcek =="u":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 23:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="V" or chcek =="v":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 24:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="W" or chcek =="w":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 25:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="X" or chcek =="x":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 26:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="Y" or chcek =="y":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)
           
elif  mode == 27:
    urls=links()
    for video in urls:
        chcek=video[0][0]
        if chcek=="Z" or chcek =="z":
           url="http://dl.hastidownload.info/1/"+video
           item = xbmcgui.ListItem(label=video)
           xbmcplugin.addDirectoryItem(_handle, url, item, isFolder=0)

xbmcplugin.endOfDirectory(_handle)