# -*- coding: utf-8 -*-
import requests,re
from bs4 import BeautifulSoup
 
def GetSeries(url):
     
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    
    Source =  soup.findAll('div', {"id": "page-right"})
    showsList = []
    for scripts in Source:
        div =  soup.findAll('div', {"class": "compact-progress-div"})
        for script in div:
            title =  script.find('div').text
            image = script.find('img').get('src')
            url = 'http://www.tvil.me/?page=view&id='+script.get('id').replace('link-','')+'&mode=v'
            showsList.append({'title':title,'url':url,'image':image})
    return showsList

def GetSeason(url):
 
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html5lib')

    Source =  soup.find('div', {"id": "view-seasons-show"}).findAll('div')
    seasonList = []
    for link in Source:
        title = u'עונה ' + link.a.text
        url = link.a.get('href')
        seasonList.append({'title':title,'url':url})
    return seasonList
    
def GetEpisodes(url):

    match=url.strip("http://www.tvil.me/view/").split("/")
    r = requests.get("http://www.tvil.me/ajax.php?module=changeSeason&showID=%s&season=%s"%(match[0],match[1]))
    soup = BeautifulSoup(r.text, 'html5lib')
    episodesList = []
    for link in soup.find_all('a'):
        title = u'פרק ' + (link.string)
        url = (link.get('href'))
        episodesList.append({'title':title,'url':url})
    return episodesList

def GetSearch(query):
    r = requests.get('http://www.tvil.me/ajax.php?module=search&input='+query.replace(' ','+'))
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    results = soup.findAll('div',{'class':'search-result'})
    
    resultsList = []
    for result in results:
        if result.find('a') != None:
            resultsList.append({'title':result.find('a').text,'url':result.find('a').get('href'),'thumbnail':result.find('img').get('src')})
        
    return resultsList


def GetStreams(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html5lib')
    soup.prettify()
    divs = soup.findAll('div', {"class": "view-watch-button"})
    divs += soup.findAll('div', {'class': 'view-download-button'})
    streamsList = []
    for link in divs:
        try:
            title = link.find('a').text
            url = link.find('a').get('href').strip('\n')
            streamsList.append({'title': title, 'url': url})
        except:
            pass
    return streamsList

def upf(url):
   url = str(url)
   host = "http://down.upf.co.il/downloadnew/file/"
   fileid = url.strip("http://down.upf.co.il/file/").strip(".htm")

   r = requests.get(url)
   if r.status_code == 404 :
       return False
   else:
       soup = BeautifulSoup(r.text, 'html5lib')
       soup.prettify()
       hash = (soup.find('input', {'name': 'hash'}))#.get('value')
       link = host + fileid + "/" + hash
   return link

def wholecloud(url):
    url = url.replace('video/', 'embed/?v=')
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html5lib')
    soup.prettify()
    return soup.find('source', {'type': "video/x-flv"}).get('src')

def uptobox(url):
    url = url.replace("uptobox", "uptostream")
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html5lib')
    return "http:%s" % (soup.find('source').get('src'))

