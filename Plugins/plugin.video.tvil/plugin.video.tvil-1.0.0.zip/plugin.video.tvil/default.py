# -*- coding: utf-8 -*-
import tvil,plugintools,urllib,xbmcplugin,xbmc,xbmcgui,urlresolver
__addonname__="Tvil.me"
def get_shows():
    plugintools.add_item(title=u'[I][B][COLOR white]חיפוש[/COLOR][/B][/I]',action='search',thumbnail='https://cdn1.iconfinder.com/data/icons/user-interface-elements/154/search-loop-512.png')
    url = 'http://www.tvil.me/?page=allseries'
    showsList = tvil.GetSeries(url)
    for show in showsList:
        plugintools.add_item(title=show.get('title'),extra=show.get('title').encode('utf-8'),action='showseasons',url=show.get('url'),thumbnail=show.get('image'))
    plugintools.close_item_list()

def get_season(url,extra,thumbnail):
    seasonList = tvil.GetSeason(url)
    for season in seasonList:        
        plugintools.add_item(title=season.get('title'),extra=season.get('title').encode('utf-8')+" "+extra,thumbnail=thumbnail,action='showepisodes',url=season.get('url'))
    plugintools.close_item_list()
    
def get_episodes(url,extra,thumbnail):

    epsList = tvil.GetEpisodes(url)
    for episode in epsList:
        plugintools.add_item(title=episode.get('title'),extra=episode.get('title').encode('utf-8')+" "+extra,thumbnail=thumbnail,action='links',url=episode.get('url'))
    plugintools.close_item_list()

def get_links(url,extra,thumbnail):
    streamsList = tvil.GetStreams(url)
    for stream in streamsList:
        plugintools.add_item(title=stream.get('title'),extra=extra,thumbnail=thumbnail,action='stream',url=stream.get('url'))
    plugintools.close_item_list()

def get_search():
    searchtext=""
    keyboard = xbmc.Keyboard(searchtext,u'הקלד שם סדרה')
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        results = tvil.GetSearch(keyboard.getText())
        for series in results:
            plugintools.add_item(title=series.get('title'),action='showseasons',url=series.get('url'),thumbnail=series.get('thumbnail'))
        plugintools.close_item_list()
        
def playVideo(url,title,thumbnail):
    import sys
    sys.path.append("C:\Program Files (x86)\JetBrains\PyCharm 2016.3\debug-eggs\pycharm-debug-py3k.egg")
    import pydevd
    pydevd.settrace('localhost', port=56789, stdoutToServer=True, stderrToServer=True)

    final=urlresolver.HostedMediaFile(url)
    new_url=final.get_url()
    if 'upf' in new_url:
        resolved_url = tvil.upf(new_url)
    elif 'wholecloud' in new_url or 'movshare' in new_url:
        resolved_url = tvil.wholecloud(new_url)
    elif 'uptostream' in new_url or "uptobox" in new_url:
        resolved_url = tvil.uptobox(new_url)
    else:
        resolved_url=urlresolver.resolve(new_url)
    stream(resolved_url,title,thumbnail)
    
def stream(url,title,thumbnail):
    path=url
    if (path == False):
        xbmcgui.Dialog().ok(__addonname__, "[COLOR red]Error 404 File Not Found[/COLOR]")
    else:
        li = xbmcgui.ListItem(label=title, iconImage=thumbnail, thumbnailImage=thumbnail,path=path)
        li.setInfo(type='Video', infoLabels={ "Title": str(title) })
        xbmc.Player().play(path,li)
    
def run():
    params = plugintools.get_params()
    action = params.get('action')
    if action == None:
        get_shows()
    elif action == 'showseasons':
        get_season(params.get('url'),params.get('title'),params.get('thumbnail'))
    elif action == 'search':
        get_search()
    elif action == 'showlist':
        get_shows()
    elif action == 'showepisodes':
        get_episodes(params.get('url'),params.get('extra'),params.get('thumbnail'))
    elif action == 'links':
        get_links(params.get('url'),params.get('extra'),params.get('thumbnail'))    
    elif action == 'stream':
        playVideo(urllib.unquote_plus(params.get('url')),params.get('extra'),params.get('thumbnail'))
    
run()