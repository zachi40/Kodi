# -*- coding: utf-8 -*-
# Module: default
# Author: zahi ohana
# Created on: 23.05.2016

import profile, urllib, urllib2, re, sys, os, xbmcplugin, xbmcgui
_url = sys.argv[0]
_handle = int(sys.argv[1])


"""
REMOTE_DBG = True

if REMOTE_DBG:
    try:
        #sys.path.append("C:\Users\zahi\AppData\Roaming\Kodi\system\pyton\pysrc)
        import pysrc.pydevd as pydevd 
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)
      """
      
PluginName="מצלמות חיות"
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.LiveCam/resources/img', ''))

def addDir(name,mode,iconimage):
    #url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"name="+urllib.quote_plus(name)
    u=sys.argv[0] + "?mode=" + str(mode)
    list=xbmcgui.ListItem(name, iconImage="DefaultFolder.png",thumbnailImage=iconimage)
    list.setInfo(type="Video", infoLabels={ "Title": name })
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=list,isFolder=True)
    return ok

def additem(name,url,mode,iconimage):
    #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="iconimage", thumbnailImage=iconimage)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
    return ok
  
def main_menu(): 
    addDir('[COLOR blue][B]מצלמות מישראל[/B][/COLOR]', 1, art+'Folder-icon.png')
    addDir('[COLOR green][B]מצלמות מהעולם[/B][/COLOR]', 2, art+'Folder-icon.png')
    addDir('[COLOR yellow][B]מצלמות בעלי חיים[/B][/COLOR]', 3, art+'Folder-icon.png')
    
def israel():
    addDir('[COLOR blue][B]מצלמות תנועה[/B][/COLOR]', 4, art+'Traffic.png')
    addDir('[COLOR orange][B]מצלמות חוף[/B][/COLOR]', 5, art+'Beach.png')
    addDir('[COLOR lime][B]מצלמות ערים[/B][/COLOR]', 6, art+'jerusalem.png')

def world():
    additem('[B]שידור מתחלף[COLOR green]שידור מתחלף - [/COLOR][/B]', 'rtmp://video3.earthcam.com:1935/fecnetwork playpath=4717.flv swfUrl=http://www.earthcam.com/swf/images/stream_viewer.swf?anticache=20140212&imageOverlay=&path=rtmp://video3.earthcam.com/fecnetwork/4717.flv&loadingimage=&buffer=3&volume=0 pageUrl=http://www.earthcam.com/',33, '#')
    additem('[B]מגדל אייפל[COLOR green]צרפת - [/COLOR][/B]', 'rtmp://46.105.54.176:80/64connections/Pariscam3.stream' ,33, 'https://upload.wikimedia.org/wikipedia/commons/7/79/Paris_06_Eiffelturm_4828.jpg')
    additem('[B]סנט פטרסבורג[COLOR green]רוסיה - [/COLOR][/B]', 'http://stream04.earthtv.com:1935/liveedge/LED/chunklist_w335190657.m3u8?55f2c41fbbf04742580278a5' ,33, 'http://authentico.co.il/wp-content/uploads/2014/07/gsharimstp.jpg')
    additem('[B]אומן - רחוב פושקינה[COLOR green]רוסיה - [/COLOR][/B]', 'rtmp://91.202.144.50:1935/live/ playpath=test1 swfUrl=http://91.202.144.50:8080/jwplayer/jwplayer.flash.swf pageUrl=http://www.umanshalom.co.il/html/uman_cameras/uman_camera1.html',33, 'http://www.umanshalom.co.il/images/uman_cameras/1.jpg')
    additem('[B]אומן - ככר פושקינה[COLOR green]רוסיה - [/COLOR][/B]', 'rtmp://91.202.144.50:1935/live/ playpath=test4 swfUrl=http://91.202.144.50:8080/jwplayer/jwplayer.flash.swf pageUrl=http://www.umanshalom.co.il/html/uman_cameras/uman_camera4.html',33, 'http://www.umanshalom.co.il/images/uman_cameras/4.jpg')
    additem('[B]רייקה[COLOR green]קרואטיה - [/COLOR][/B]', 'rtmp://cdn-03.whatsupcams.com/live playpath=hr_rijeka06 swfUrl=http://www.whatsupcams.com/static/flowplayer/flowplayer.swf pageUrl=http://www.whatsupcams.com/wgt/hr_rijeka06/768/480/true/',33, 'http://www.yahav.org/_media/mediabank/2735_mb_file_4d2bb.jpg')
    additem('[B]סידני - גשר נמל ומגדל האופרה[COLOR green]אוסטרליה - [/COLOR][/B]', 'rtmp://110.232.113.71/live playpath=kirribilli.stream swfUrl=http://www.captiveye-kirribilli.info/stream_auth/public/passive_b14f_800x450.swf?vol=0 pageUrl=http://www.captiveye-kirribilli.info/stream_auth/public/default.asprtmp://110.232.113.71/live/kirribilli.stream',33, '#')
    additem('[B]ריו[COLOR green]ברזיל - [/COLOR][/B]', 'rtmp://video3.earthcam.com:1935/fecnetwork playpath=6593.flv swfUrl=http://static.earthcamcdn.com/swf/streaming/stream_viewer_v3.swf?201605201630 pageUrl=http://www.earthcam.com/brazil/riodejaneiro/?cam=rio_copacabana',33, '#')

def animals():
    additem('[B]הגן הזולוגי,מאורת הפנדה[COLOR yellow]וושינגטון הבירה - [/COLOR][/B]', 'rtmp://160.111.252.71:1935/live_edge_panda/_definst_/panda02_480p', 34, 'http://www.snopi.com/xenc/images/panda.jpg')
    additem('[B]הגן הזולוגי, מאורת הפילים[COLOR yellow]וושינגטון הבירה - [/COLOR][/B]', 'rtmp://160.111.252.144/live_edge//elephant04_360', 34, 'http://www.fun.mivzakon.co.il/pictures/pictures/1(804).jpg')
    additem('[B]הגן הזולוגי, מאורת האריות[COLOR yellow]וושינגטון הבירה - [/COLOR][/B]', 'rtmp://160.111.252.144/live_edge//lion_yard_360', 34, 'http://blog.tapuz.co.il/levrosh/images/3453250_51.jpg')
    additem('[B]סיס החומות[COLOR yellow]גבעתיים - [/COLOR][/B]', 'rtmp://server1.reali-tech.com/live//amnon.stream', 34, 'http://www.birds.org.il/Data/Portal%20Images/Apodiformes/%D7%A1%D7%99%D7%A1%D7%97%D7%95%D7%9E%D7%95%D7%AA-%D7%90%D7%9E%D7%99%D7%A8%D7%91%D7%9F%D7%93%D7%91-2_1910376715.jpg.ashx?width=451&height=412')
    additem('[B]בית שיף, סיס החומות[COLOR yellow]תל אביב - [/COLOR][/B]', 'rtmp://server1.reali-tech.com/live/sisim.stream', 34, 'http://www.birds.org.il/Data/Portal%20Images/Apodiformes/%D7%A1%D7%99%D7%A1%D7%97%D7%95%D7%9E%D7%95%D7%AA-%D7%90%D7%9E%D7%99%D7%A8%D7%91%D7%9F%D7%93%D7%91-2_1910376715.jpg.ashx?width=451&height=412')
    additem('[B]חיוויאי הנחשים[COLOR yellow]מיקום לא ידוע - [/COLOR][/B]', 'http://80.244.172.24/teva3-aac/teva3-hi-aac.m3u8', 34, 'http://www.birds.org.il/Data/Portal%20Images/Falconiformes/%D7%97%D7%95%D7%95%D7%99%D7%90%D7%99%D7%94%D7%A0%D7%97%D7%A9%D7%99%D7%9D-2-%D7%9C%D7%98%D7%A7%D7%A1%D7%98-%D7%93%D7%95%D7%93%D7%93%D7%A0%D7%99%D7%90%D7%9C-_1585108305.jpg')
    additem('[B]תנשמת לבנה[COLOR yellow]באר טוביה - [/COLOR][/B]', 'rtmp://server1.reali-tech.com/live/avigdor.stream', 34, 'http://www.birds.org.il/Data/Birds/Yoav%20Perlman/%D7%AA%D7%A0%D7%A9%D7%9E%D7%AA%D7%9C%D7%91%D7%A0%D7%94-001_24039961.jpg')

def trafic():
    additem('[B]הרצליה[COLOR blue]הרצליה - [/COLOR][/B]', 'http://194.90.203.126:8000/cam12',30, 'http://www.ayalonhw.co.il//download/cameras/camera_12.jpg')
    additem('[B]חולון[COLOR blue]חולון - [/COLOR][/B]', 'http://194.90.203.126:8000/cam2',30, 'http://www.ayalonhw.co.il//download/cameras/camera_2.jpg')
    additem('[B]וולפסון[COLOR blue]חולון - [/COLOR][/B]', 'http://194.90.203.126:8000/cam13',30, 'http://www.ayalonhw.co.il//download/cameras/camera_13.jpg')
    additem('[B]כביש 1[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam1',30, 'http://www.ayalonhw.co.il//download/cameras/camera_1.jpg')
    additem('[B]קיבוץ גלויות[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam3',30, 'http://www.ayalonhw.co.il//download/cameras/camera_3.jpg')
    additem('[B]לה גרדיה[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam4',30, 'http://www.ayalonhw.co.il//download/cameras/camera_4.jpg')
    additem('[B]יצחק שדה[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam5',30, 'http://www.ayalonhw.co.il//download/cameras/camera_5.jpg')
    additem('[B]השלום[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam6',30, 'http://www.ayalonhw.co.il//download/cameras/camera_6.jpg')
    additem('[B]ארלוזרוב[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam7',30, 'http://www.ayalonhw.co.il//download/cameras/camera_7.jpg')
    additem('[B]ההלכה[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam8',30, 'http://www.ayalonhw.co.il//download/cameras/camera_8.jpg')
    additem('[B]רוקח[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam9',30, 'http://www.ayalonhw.co.il//download/cameras/camera_9.jpg')
    additem('[B]קק"ל[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam10',30, 'http://www.ayalonhw.co.il//download/cameras/camera_10.jpg')
    additem('[B]גלילות[COLOR blue]תל אביב - [/COLOR][/B]', 'http://194.90.203.126:8000/cam11',30, 'http://www.ayalonhw.co.il//download/cameras/camera_11.jpg')

def Beach():
    additem('[B]חוף בת-ים[COLOR orange]בת ים - [/COLOR][/B]', 'rtmp://server1.reali-tech.com/live//batyam20',31, 'http://intersurf.co.il/~almog/img/cms/intersurf_cam_batyam.jpg')
    additem('[B]חוף הילטון[COLOR orange]תל אביב - [/COLOR][/B]', 'rtmp://server1.reali-tech.com/live//inter20.stream',31, 'http://intersurf.co.il/~almog/img/cms/intersurf_cam_hilton.jpg')
    additem('[B]חוף הדולפינריום[COLOR orange]תל אביב - [/COLOR][/B]', 'http://livestream.cdn-surfline.com/cdn-live/_definst_/surfline/secure/live/il-dolphbeachcam.smil/chunklist_w1789525512_b800000.m3u8?e=1465219717&h=0e808033ef7a68a43c7969f45ccaa5d7',31, 'http://israelsurfclub.co.il/wp-content/uploads/dolphiCam.jpg')
    additem('[B]חוף הדולפינריום 2[COLOR orange]תל אביב - [/COLOR][/B]', 'http://server1.reali-tech.com:1935/live/dolphin.stream/playlist.m3u8',31, 'http://israelsurfclub.co.il/wp-content/uploads/dolphiCam.jpg')
    additem('[B]חוף עין גב[COLOR orange]כנרת - [/COLOR][/B]', 'http://livestream.cdn-surfline.com/cdn-live/_defnst_/surfline/secure/live/il-dolphbeachcam.smil/chunklist_w1789525512_b800000.m3u8?e=1465219717&h=0e808033ef7a68a43c7969f45ccaa5d7',31, 'http://www.ligdol.co.il/Upload/Attractions/eingev3.jpg')
    additem('[B]קייקי כפר בלום[COLOR orange]קיבוץ כפר בלום - [/COLOR][/B]', 'rtmp://server1.reali-tech.com/live//blom.stream',31, 'http://www.kayaks.co.il/wp-content/themes/kayaks/images/kayaks-header-logo.png')

def IsraelCity():
    additem('[B]רכבל תחתון[COLOR lime]אתר החרמון - [/COLOR][/B]', 'http://s2.ipcamlive.com/streams/025753794430fcdba/stream.m3u8',32, 'https://upload.wikimedia.org/wikipedia/he/1/15/Jermon_logo.JPG')
    additem('[B]רכבל עליון[COLOR lime]אתר החרמון - [/COLOR][/B]', 'http://s3.ipcamlive.com/streams/03575a7a83ec090b3/stream.m3u8',32, 'https://upload.wikimedia.org/wikipedia/he/1/15/Jermon_logo.JPG')
    additem('[B]מזחלת הרים אקסטרים[COLOR lime]אתר החרמון - [/COLOR][/B]', 'http://s2.ipcamlive.com/streams/02575a797b88ab468/stream.m3u8',32, 'https://upload.wikimedia.org/wikipedia/he/1/15/Jermon_logo.JPG')
    additem('[B]רחבת הכותל[COLOR lime]ירושלים - [/COLOR][/B]', 'rtmp://IL29.cast-tv.com/23595_LIVE_Kotel_Live/mp4:23595_LIVE_Kotel_Live',32, 'https://userscontent2.emaze.com/images/8ba5ebcd-fb82-4fbf-ad94-87bbddb8187c/e6cf374d-8fab-4928-974d-c956d82c865dimage1.png')
    additem('[B]רחבת התפילה[COLOR lime]ירושלים - [/COLOR][/B]', 'rtmp://IL29.cast-tv.com/23595_LIVE_Kotel_Live1/mp4:23595_LIVE_Kotel_Live1',32, 'https://userscontent2.emaze.com/images/8ba5ebcd-fb82-4fbf-ad94-87bbddb8187c/e6cf374d-8fab-4928-974d-c956d82c865dimage1.png')
    additem('[B]קשת וילסון[COLOR lime]ירושלים - [/COLOR][/B]', 'rtmp://IL29.cast-tv.com/23595_LIVE_Kotel_LIVE2/mp4:23595_LIVE_Kotel_LIVE2',32, 'https://userscontent2.emaze.com/images/8ba5ebcd-fb82-4fbf-ad94-87bbddb8187c/e6cf374d-8fab-4928-974d-c956d82c865dimage1.png')
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
params=get_params()
mode=None

try: mode=int(params["mode"])
except:
    try: 
        mode=params["mode"]
    except: pass

 

if mode == None:
    main_menu()
elif mode == 1:
    israel()
elif mode == 2:
    world()
elif mode == 3:
    animals()
elif mode == 4:
    trafic()
elif mode == 5:
    Beach()
elif mode == 6:
    IsraelCity()
xbmcplugin.endOfDirectory(_handle)