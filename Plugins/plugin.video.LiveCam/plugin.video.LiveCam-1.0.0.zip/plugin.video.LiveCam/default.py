# -*- coding: utf-8 -*-
# Module: default
# Author: zahi ohama
# Created on: 23.05.2016


import sys
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

VIDEOS = {
    'מצלמות איילון':[
        {'name': 'כביש 1',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_1.jpg',
            'video': 'http://194.90.203.126:8000/cam1',
             'genre': 'camera'
        },
        {'name': 'חולון',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_2.jpg',
            'video': 'http://194.90.203.126:8000/cam2',
             'genre': 'camera'
        },
        {'name': 'קיבוץ גלויות',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_3.jpg',
           'video': 'http://194.90.203.126:8000/cam3',
            'genre': 'camera'
        },
        {'name': 'לה גוורדייה',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_4.jpg',
           'video': 'http://194.90.203.126:8000/cam4',
            'genre': 'camera'
        },
        {'name': 'יצחק שדה',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_5.jpg',
           'video': 'http://194.90.203.126:8000/cam5',
            'genre': 'camera'
        },
        {'name': 'השלום',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_6.jpg',
           'video': 'http://194.90.203.126:8000/cam6',
            'genre': 'camera'
        },
        {'name': 'ארלוזרוב',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_7.jpg',
           'video': 'http://194.90.203.126:8000/cam7',
            'genre': 'camera'
        },
        {'name': 'ההלכה',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_8.jpg',
           'video': 'http://194.90.203.126:8000/cam8',
            'genre': 'camera'
        },
        {'name': 'רוקח',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_9.jpg',
           'video': 'http://194.90.203.126:8000/cam9',
            'genre': 'camera'
        },
        {'name': 'קק"ל',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_10.jpg',
           'video': 'http://194.90.203.126:8000/cam10',
            'genre': 'camera'
        },
        {'name': 'גלילות',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_11.jpg',
           'video': 'http://194.90.203.126:8000/cam11',
            'genre': 'camera'
        },
        {'name': 'הרצליה 1',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_12.jpg',
           'video': 'http://194.90.203.126:8000/cam12',
            'genre': 'camera'
        },
        {'name': 'וולפסון',
          'thumb': 'http://www.ayalonhw.co.il/download/cameras/camera_13.jpg',
           'video': 'http://194.90.203.126:8000/cam13',
            'genre': 'camera'
        },
    ],
    'מצלמות בישראל':[
        {'name': 'חוף הדולפינריום, תל אביב',
          'thumb': 'https://upload.wikimedia.org/wikipedia/commons/5/54/Tel_Aviv_Beach.jpg',
            'video': 'rtmp://server1.reali-tech.com/live//dolphin.stream',
             'genre': 'camera'
        },
        {'name': 'חוף הדולפינריום, תל אביב',
         'thumb': 'https://upload.wikimedia.org/wikipedia/commons/5/54/Tel_Aviv_Beach.jpg',
         'video': '',
         'genre': 'camera'
         }
    ]
}


def get_categories():
    return VIDEOS.keys()


def get_videos(category):
    return VIDEOS[category]


def list_categories():
    categories = get_categories()
   
    listing = []
   
    for category in categories:
        list_item = xbmcgui.ListItem(label=category)
        list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
                          'icon': VIDEOS[category][0]['thumb'],
                          'fanart': VIDEOS[category][0]['thumb']})
        list_item.setInfo('video', {'title': category, 'genre': category})
        url = '{0}?action=listing&category={1}'.format(_url, category)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category):
    videos = get_videos(category)
    listing = []
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['name'])
        list_item.setInfo('video', {'title': video['name'], 'genre': video['genre']})
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        list_item.setProperty('IsPlayable', 'true')
        url = '{0}?action=play&video={1}'.format(_url, video['video'])
        is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'listing':
            list_videos(params['category'])
        elif params['action'] == 'play':
            play_video(params['video'])
    else:
        list_categories()


if __name__ == '__main__':
    router(sys.argv[2][1:])
