# -*- coding: utf-8 -*-
import plugintools,xbmcplugin,xbmc,xbmcgui,urlresolver
import os,sys, seretnow


sys.path.append('C:/Users/user/AppData/Roaming/Kodi/addons/plugin.video.seretnow/resources/nodejs')
# Plugin Info
__addonname__="SeretNow.Me"
__domain__= "http://seretnow.me"

# Thumbnails for item list
SEARCH_ICON     = os.path.join(plugintools.get_runtime_path(), 'resources', 'images', 'search.jpg')
ARCHIVE_ICON    = os.path.join(plugintools.get_runtime_path(), 'resources', 'images', 'archive.png')
MOVIE_ICON      = os.path.join(plugintools.get_runtime_path(), 'resources', 'images', 'movie.png')
HOT_ICON        = os.path.join(plugintools.get_runtime_path(), 'resources', 'images', 'hot.jpg')
ANIMATIONS_ICON = os.path.join(plugintools.get_runtime_path(), 'resources', 'images', 'animations.jpg')
COVER           = os.path.join(plugintools.get_runtime_path(), 'fanart.jpg')

#xbmcgui.Dialog().ok(__addonname__, "[COLOR red]Error 404 File Not Found[/COLOR]")

def get_shows():
    plugintools.add_item(title=u'[B][COLOR white]סרטים[/COLOR][/B]' , action='movies', thumbnail=MOVIE_ICON)
    plugintools.add_item(title=u'[B][COLOR white]סדרות[/COLOR][/B]', action='session', thumbnail=ARCHIVE_ICON)
    plugintools.add_item(title=u'[B][COLOR red]הכי מומלצים[/COLOR][/B]', action='hot', thumbnail=HOT_ICON)
    plugintools.add_item(title=u'[B][COLOR white]אנמציה[/COLOR][/B]', action='animations', thumbnail=ANIMATIONS_ICON)
    plugintools.add_item(title=u'[B][COLOR white]חיפוש[/COLOR][/B]' ,action='search', thumbnail=SEARCH_ICON)
    plugintools.close_item_list()

def get_search(url,numpage):
    searchtext=""
    keyboard = xbmc.Keyboard(searchtext,u'הקלד שם של סדרה או סרט')
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        results = seretnow.GetSearch(keyboard.getText(),url)
        for series in results:
            plugintools.add_item(title=series.get('title'),
                                 action=series.get('action'),
                                 url=series.get('url'),
                                 thumbnail='DefaultMovies.png')
        plugintools.close_item_list()

def get_hot(url):
    updates = seretnow.GetHot(url)
    for update in updates:
        plugintools.add_item(title=update.get('title'),
                             action=update.get('action'),
                             url=update.get('url'),
                             thumbnail='DefaultMovies.png')
    plugintools.close_item_list()

def get_nextpage(domain,url):
    results = seretnow.GetNextPage(domain,url)
    for series in results:
        plugintools.add_item(title=series.get('title'),
                             action=series.get('action'),
                             url=series.get('url'),
                             thumbnail='DefaultMovies.png')
    plugintools.close_item_list()

def get_sources(title,thumbnail,url):
    sources = seretnow.GetSources(url)
    for source in sources:
        plugintools.add_item(title=source.get('title'),
                             action=source.get('action'),
                             url=source.get('url'),
                             thumbnail='DefaultMovies.png')
    plugintools.close_item_list()

def get_sessionstream(url,title,thumbnail):
    sources = seretnow.GetSessionStream(url,title)
    if sources == "don't to be broadcast":
        xbmcgui.Dialog().ok(__addonname__, "[B][COLOR white]הפרק עדיין לא שודר[/COLOR][/B]")
    else:
        for source in sources:
            plugintools.add_item(title=source.get('title'),
                                 action=source.get('action'),
                                 url=source.get('url'),
                                 thumbnail='DefaultMovies.png')
        plugintools.close_item_list()

def get_animations(url):
    sources = seretnow.GetAnimations(url)
    for source in sources:
        plugintools.add_item(title=source.get('title'),
                             action=source.get('action'),
                             url=source.get('url'))
                             #thumbnail=source.get('thumbnail'))
    plugintools.close_item_list()

def get_moviescategory(url):
    sources = seretnow.GetMoviesCategory(url)
    for source in sources:
        plugintools.add_item(title=source.get('title'),
                             action=source.get('action'),
                             url=source.get('url'))
        # thumbnail=source.get('thumbnail'))
    plugintools.close_item_list()

def get_movielist(url, title,thumbnail):
    sources = seretnow.GetMoviesList(url)
    for source in sources:
        plugintools.add_item(title=source.get('title'),
                             action=source.get('action'),
                             url=source.get('url'),
                             thumbnail=source.get('thumbnail'))
    plugintools.close_item_list()

def get_session(title, thumbnail, url):
    sources = seretnow.GetSession(url)
    for source in sources:
        plugintools.add_item(title=source.get('title'),
                             action=source.get('action'),
                             url=source.get('url'),
                             thumbnail=source.get('thumbnail'))

def get_SessionCatgory(url):
    sources = seretnow.GetSessionCategory(url)
    for source in sources:
        plugintools.add_item(title=source.get('title'),
                             action=source.get('action'),
                             url=source.get('url'),
                             thumbnail=source.get('thumbnail'))
    plugintools.close_item_list()

def get_sessionlist(url, title,thumbnail):
    sources = seretnow.GetSessionList(url)
    for source in sources:
        plugintools.add_item(title=source.get('title'),
                             action=source.get('action'),
                             url=source.get('url'),
                             thumbnail=source.get('thumbnail'))
    plugintools.close_item_list()


def playVideo(url,title,thumbnail):
    oldtitle=title
    url,title = seretnow.GetStreamUrl(url)
    if title == "Movie":
        title=oldtitle
    if url and not '.f4mTester' in url and url != "404":
            li = xbmcgui.ListItem(label=title, iconImage=thumbnail, thumbnailImage=thumbnail, path=url)
            li.setInfo(type='Video', infoLabels={"Title": (title)})
            xbmc.Player().play(url, li)
    elif url and url != "404":
        xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
    else:
        xbmcgui.Dialog().ok(__addonname__, "[COLOR red][B]Error 404 File Not Found[/B][/COLOR]")


def run():
    params = plugintools.get_params()
    action = params.get('action')
    if action == None:
        get_shows()
    elif action == 'session':
        get_SessionCatgory(__domain__)
    elif action == 'movies':
        get_moviescategory(__domain__)
    elif action == 'animations':
        get_animations(__domain__)
    elif action == 'search':
        get_search(__domain__,params.get('url'))
    elif action == 'hot':
        get_hot(__domain__)
    elif action == 'nextpage':
        get_nextpage(__domain__,params.get('url'))
    elif action == 'showsources':
        get_sources(params.get('title'),params.get('thumbnail'),params.get('url'))
    elif action == 'showsession':
        get_session(params.get('title'), params.get('thumbnail'), params.get('url'))
    elif action == 'sessionstreamurl':
        get_sessionstream(params.get('url'),params.get('title'),params.get('thumbnail'))
    elif action == 'sessionlist':
        get_sessionlist(params.get('url'),params.get('title'),params.get('thumbnail'))
    elif action == 'movieslist':
        get_sessionlist(params.get('url'), params.get('title'), params.get('thumbnail'))
    elif action == 'play':
        playVideo(params.get('url'),params.get('title'),params.get('thumbnail'))

run()

#import sys
# sys.path.append("C:\Program Files (x86)\JetBrains\PyCharm 2017.1\debug-eggs\pycharm-debug.egg")
#sys.path.append("C:\Program Files (x86)\JetBrains\PyCharm 2016.3.3\debug-eggs\pycharm-debug.egg")
#import pydevd
#pydevd.settrace('localhost', port=4444, stdoutToServer=True, stderrToServer=True)
