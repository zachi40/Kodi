# -*- coding: utf-8 -*-

from resources import cfscrape
from bs4 import BeautifulSoup
from base64 import b64decode
import urllib,re, requests,json,time
import sys,os
import sys

import os
#def _is_windows():
#_external_runtime.py

def getMovie():
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get("http://www.hadlafa.net/search/label/%D7%A1%D7%A8%D7%98%D7%99%D7%9D")  # or post()
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    results = soup.findAll('div', {'class': 'blog-item-wrap'})
    resultsList = []
    for result in results:
        if ((result.text).replace('\n', '')) == u'ארכיון הסדרות של הדלפה  ' or \
                        ((result.text).replace('\n', '')) == u'ימים ושעות שידור – סדרות ישראליות  ':
            pass
        elif result.find('a') != None:
            resultsList.append({'title': (result.text).replace('\n', ''),
                                'url': result.find('a').get('href'),
                                'thumbnail': result.find('img').get('src')})
    return resultsList

def GetHot(url):
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get("http://www.seretnow.me/")  # or post()
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    updatesline = soup.findAll('div', {'class': 'td-trending-now-post'})
    updatesList = []
    for update in updatesline:
        updatesList.append({'title': update.find('a').get('title'),
                            'url': update.find('a').get('href'),
                            'action': 'showsources',
                            'thumbnail': 'DefaultMovies.png'})
    return updatesList

#print getMovie()
print GetHot('http://seretnow.me/')