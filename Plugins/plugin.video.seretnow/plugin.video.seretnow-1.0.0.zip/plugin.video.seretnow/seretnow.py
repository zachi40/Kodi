# -*- coding: utf-8 -*-
from resources import cfscrape
from bs4 import BeautifulSoup
from base64 import b64decode
import urllib,re, requests,json,time,urlresolver
#############################

#server Ad
def cllkme(url):
    regex = r'sessionId: \"(.*?)\"'
    urlregex = r"http:\/\/clkme.\in\/(.*)"
    url="http://cllkme.com/%s" %(re.findall(urlregex, url)[0])
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    links = soup.findAll('script', {'type': 'text/javascript'})
    tokenid = re.findall(regex, str(links))[0]
    request ='http://cllkme.com/shortest-url/end-adsession?adSessionId='+ tokenid
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36','Referer': '%s'%(url)}
    response = requests.get(request, headers=headers)
    while response.status_code == 404:
        response = requests.get(request, headers=headers)

    getlink=json.loads(response.text)
    return getlink.get(u'destinationUrl')

def clkmein(url):
    regex = r'sessionId: \"(.*?)\"'
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    links = soup.findAll('script', {'type': 'text/javascript'})
    tokenid = re.findall(regex, str(links))[0]
    request ='http://cllkme.com/shortest-url/end-adsession?adSessionId='+ tokenid
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36','Referer': '%s'%(url)}
    response = requests.get(request, headers=headers)
    while response.status_code == 404:
        response = requests.get(request, headers=headers)

    getlink=json.loads(response.text)
    return getlink.get(u'destinationUrl')

def sh(url):
    regex = r'sessionId: \"(.*?)\"'
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    links = soup.findAll('script', {'type': 'text/javascript'})
    tokenid = re.findall(regex, str(links))[0]
    request = 'http://cllkme.com/shortest-url/end-adsession?adSessionId=' + tokenid
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
        'Referer': '%s' % (url)}
    response = requests.get(request, headers=headers)
    while response.status_code == 404:
        response = requests.get(request, headers=headers)

    getlink = json.loads(response.text)
    return getlink.get(u'destinationUrl')

def adfly(url):
    HTTP_HEADER = {
        "User-Agent": 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36',
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Encoding": "gzip,deflate,sdch",
        "Connection": "keep-alive",
        "Accept-Language": "nl-NL,nl;q=0.8,en-US;q=0.6,en;q=0.4",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache"
    }
    r = requests.get(url, headers=HTTP_HEADER, timeout=10)
    html = r.text
    ysmm = re.findall(r"var ysmm =.*\;?", html)
    if len(ysmm) > 0:
        ysmm = re.sub(r'var ysmm \= \'|\'\;', '', ysmm[0])
        left = ''
        right = ''
        for c in [ysmm[i:i + 2] for i in range(0, len(ysmm), 2)]:
            left += c[0]
            right = c[1] + right
        decoded_uri = b64decode(left.encode() + right.encode())[2:].decode()
        if re.search(r'go\.php\?u\=', decoded_uri):
            decoded_uri = b64decode(re.sub(r'(.*?)u=', '', decoded_uri)).decode()
        return decoded_uri

def viid(url):
    regex = r'sessionId: \"(.*?)\"'
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    links = soup.findAll('script', {'type': 'text/javascript'})
    tokenid = re.findall(regex, str(links))[0]
    request = 'http://cllkme.com/shortest-url/end-adsession?adSessionId=' + tokenid
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
        'Referer': '%s' % (url)}
    response = requests.get(request, headers=headers)
    while response.status_code == 404:
        response = requests.get(request, headers=headers)

    getlink = json.loads(response.text)
    return getlink.get(u'destinationUrl')

#host
def vidto_me(url):
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    id = soup.findAll('input', {'name': 'id'})[0]
    fname = soup.findAll('input', {'name': 'fname'})[0]
    token = soup.findAll('input', {'name': 'hash'})[0]
    request = 'op=download1&usr_login=&id=%s&fname=%s&referer=&hash=%s&imhuman=Proceed+to+video' % (
    id.get('value'), fname.get('value'), token.get('value'))
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    time.sleep(7)
    r = requests.post(url, data=request, headers=headers)
    soup = BeautifulSoup(r.text, 'html5lib')
    javalink = soup.findAll('div', {'class': 'download-private'})[0]
    regex36p = r"{file:\"(.+)\",label:\"360p"
    regex240p = r"{file:\"(.+)\",label:\"240p"
    if re.findall(regex36p, str(javalink), re.DOTALL)[0] != None:
        return re.findall(regex36p, str(javalink), re.DOTALL)[0], fname.get('value')
    elif re.findall(regex240p, str(javalink), re.DOTALL)[0] != None:
        return re.findall(regex240p, str(javalink), re.DOTALL)[0], fname.get('value')
    else:
        return "Error 404","Error 404"

def myfile(url):
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    text = soup.findAll('script', {'language': 'Javascript'})
    regex = r"[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?"
    matches = re.finditer(regex, str(text), re.IGNORECASE)
    http_links = []
    for i in matches:
        http_links.append(i.group())
    filename = \
    soup.findAll('div', {'style': 'overflow: hidden;white-space: pre-wrap;text-overflow: ellipsis;width: 100%;'})[0]
    return http_links[3], filename.find('a').text

def upf(url):
   url = str(url)
   host = "http://down.upf.co.il/downloadnew/file/"
   fileid = url.strip("http://down.upf.co.il/file/").strip(".htm")

   r = requests.get(url)
   if r.status_code == 404:
       return "404","Error"
   else:
       soup = BeautifulSoup(r.text, 'html5lib')
       soup.prettify()
       hash = (soup.find('input', {'name': 'hash'}))
       #"<div class="view"
       filename = (soup.find('div', {'class': 'view'}))
       link = "%s%s/%s"%(host,fileid ,hash.get("value"))
   return link,(filename.find("a").get("title"))

##################################

def GetSearch(query,url):
    resultsList = []
    query=urllib.quote(query)
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get("%s/?s=%s" % (url, query))
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    pages = soup.find('a', {'class': 'page'})
    results = soup.findAll('div', {'class': 'td-module-thumb'})

    for result in results:
        resultsList.append({'title': result.find('a').get('title'),
                            'url': result.find('a').get('href'),
                            'action': 'showsources',
                            'thumbnail': result.find('img').get('src')})
    if pages != None:
        nextpage = "%s/page/%s/?s=%s" %(url, pages.text,query)
        resultsList.append({'title':u'עמוד הבא', 'action':'nextpage', 'url':nextpage, 'thumbnail':'DefaultFolder.png'})
    return resultsList

def GetHot(url):
    updatesList = []
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    updatesline = soup.findAll('div', {'class': 'td-trending-now-post'})
    for update in updatesline:
        updatesList.append({'title': update.find('a').get('title'),
                            'url': update.find('a').get('href'),
                            'action': 'showsources',
                            'thumbnail': 'DefaultMovies.png'})
    return updatesList

def GetAnimations(url):
    url="%s/category/אנימציה"%(url)
    movieslist = []
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    pages = soup.find('a', {'class': 'page'})
    data = soup.findAll('div', {'class': 'td-main-content-wrap'})
    results_data = BeautifulSoup(str(data), 'html5lib')
    movies = results_data.findAll('div', {'class': 'td-module-thumb'})

    for movie in movies:
        movieslist.append({'title': movie.find('a').get('title').decode('unicode-escape'),
                            'url': movie.find('a').get('href'),
                            'action': 'showsources',
                           'thumbnail': 'DefaultMovies.png'})
    if pages != None:
        print (url, str(pages.text))
        nextpage = ("%s/page/%s" % (url, str(pages.text))).decode('UTF-8')
        movieslist.append({'url': nextpage,'action': 'nextpage', 'thumbnail': 'DefaultFolder.png','title': u'עמוד הבא' })
    return movieslist

def GetMoviesList(url):
    MoviesList = []
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    pages = soup.find('a', {'class': 'page'})
    data = soup.findAll('div', {'class': 'td-main-content-wrap'})
    results_data = BeautifulSoup(str(data), 'html5lib')
    Movies = results_data.findAll('div', {'class': 'td-module-thumb'})
    if len(Movies) == 0:
        return Movies
    else:
        for Movie in Movies:
            MoviesList.append({'title': Movie.find('a').get('title').decode('unicode-escape'),
                               'url': Movie.find('a').get('href'),
                               'action': 'showsources',
                               'thumbnail': 'DefaultMovies.png'})
        if pages != None:
            print (url, str(pages.text))
            nextpage = ("%s/page/%s" % (url, str(pages.text))).decode('UTF-8')
            MoviesList.append({'url': nextpage, 'action': 'nextpage', 'thumbnail': 'DefaultFolder.png', 'title': u'עמוד הבא'})
        return MoviesList

def GetMoviesCategory(url):
    MoviesCategoryList = []
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    MoviesCategorys = soup.findAll('li')
    for Category in MoviesCategorys[9:13]:
        MoviesCategoryList.append({'title': Category.text, 'url': Category.find('a').get('href'), 'action': 'movieslist','thumbnail': 'DefaultFolder.png'})
    return MoviesCategoryList

def GetSessionList(url):
    SessionList = []
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    pages = soup.find('a', {'class': 'page'})
    data = soup.findAll('div', {'class': 'td-main-content-wrap'})
    results_data = BeautifulSoup(str(data), 'html5lib')
    Sessions = results_data.findAll('div', {'class': 'td-module-thumb'})
    if len(Sessions) == 0:
        return Sessions
    else:
        for Session in Sessions:
            SessionList.append({'title': Session.find('a').get('title').decode('unicode-escape'),
                               'url': Session.find('a').get('href'),
                               'action': 'showsources',
                               'thumbnail': 'DefaultMovies.png'})
        if pages != None:
            print (url, str(pages.text))
            nextpage = ("%s/page/%s" % (url, str(pages.text))).decode('UTF-8')
            SessionList.append({'url': nextpage, 'action': 'nextpage', 'thumbnail': 'DefaultFolder.png', 'title': u'עמוד הבא'})
        return SessionList

def GetSessionCategory(url):
    SessionListcatgory = []
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    SessionList = soup.findAll('ul', {'class': 'sub-menu'})[1]
    for Session in SessionList:
        try:SessionListcatgory.append({'title':Session.find("a").text,'url': Session.find("a").get("href"), 'action': 'sessionlist','thumbnail': 'DefaultFolder.png'})
        except:pass
    return SessionListcatgory

def GetSession(url):
    sessionlist = []
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    try:
        trailer = soup.findAll('iframe', {'class': 'youtube-player'})[0]
        sessionlist.append({'title': u'טריילר', 'url': trailer.get('src'), 'action': 'play', 'thumbnail': 'DefaultMovies.png'})
    except:
        pass

    data = soup.findAll('div', {'class': 'td-main-content-wrap'})
    results_data = BeautifulSoup(str(data), 'html5lib')
    sessions = results_data.findAll('p', {'style': 'text-align: center;'})

    for session in sessions:
        title = (session.text).decode('unicode-escape').strip(":")
        if u'פרק' in title :#and u'עונה' in title:
            sessionlist.append({'title': (session.text).decode('unicode-escape').strip(":"),'url': url, 'action': 'sessionstreamurl','thumbnail': 'DefaultMovies.png'})
    return sessionlist

def GetSessionStream(url,title):
    sourceslist = []
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    episodes = soup.findAll('p', {'style': 'text-align: center;'})
    for i in range(len(episodes)):
        episode = u''.join((episodes[i].text)).encode('utf-8').strip(":")
        if episode == title:
            countr = i
            while True:
                countr = countr + 1
                try:
                    sourceslist.append(
                        {'title': episodes[countr].find("a").text, 'url': episodes[countr].find("a").get("href"),'action': 'play'})
                except:
                    break

    if len(sourceslist) == 0:
        return "don't to be broadcast"
    else:
        return sourceslist

def GetSources(url):
    sourceslist=[]
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    articleBody = soup.findAll('div', {'class': 'ptb_module ptb_title'})
    title = articleBody[0].text
    if u'כל הפרקים' in title:  #session
        return GetSession(url)
    elif u'פרק' in title:      #episode
        episodelink = soup.findAll('h1', {'style': 'text-align: center;'})
        try:
            return GetSources(episodelink[0].find("a").get("href"))
        except:
            movieslinks = soup.findAll('p', {'style': 'text-align: center;'})
            for link in movieslinks:
                if "http://" in link.text or "UPF.CO.IL" in link.text:
                    sourceslist.append(
                        {'title': link.find('a').text, 'url': link.find('a').get('href'), 'action': 'play'})
            return sourceslist
    else:                      #movie
        try:
            trailer = soup.findAll('iframe', {'class': 'youtube-player'})[0]
            sourceslist.append({'title': 'Trailer', 'url': trailer.get('src'), 'action': 'play' , 'thumbnail': 'DefaultMovies.png'})
        except:
            pass
        imgae = soup.find('figure',{'class':'ptb_post_image clearfix'})
        movieslinks = soup.findAll('p', {'style': 'text-align: center;'})
        for link in movieslinks:
            if "http://" in link.text or "UPF.CO.IL" in link.text:
                sourceslist.append({'title': link.find('a').text, 'url': link.find('a').get('href'), 'thumbnail': imgae.find("img").get("src") , 'action': 'play'})
        return sourceslist

def GetNextPage(domain,url):
    resultsList = []
    regex = r"\d."
    requests_flare = cfscrape.create_scraper()
    r = requests_flare.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    page = soup.findAll('a', {'class': 'page'})

    listpages = soup.find('span', {'class': 'pages'})
    lastpage = re.findall(regex, (listpages.text))

    data = soup.findAll('div', {'class': 'td-main-content-wrap'})
    results_data= BeautifulSoup(str(data), 'html5lib')
    results = results_data.findAll('div', {'class': 'td-module-thumb'})
    for result in results:
        resultsList.append({'title': result.find('a').get('title').decode('unicode-escape'),
                            'url': result.find('a').get('href'),
                            'action': 'showsources',
                            'thumbnail': result.find('img').get('src')})
    try:
        nextpage = page[1].text
    except:
        nextpage = page[0].text

    if page != [] and int(lastpage[0]) !=nextpage:
        current_url=(url.decode('UTF-8')).split("/")
        if "?s=" in current_url[-1]:
            nextpage = "%s/page/%s/%s" % (domain, nextpage, current_url[-1])
        else:
            nextpage = "%s/%s/%s/page/%s" % (domain, current_url[3], current_url[4], nextpage)
        resultsList.append(
            {'title': u'עמוד הבא', 'action': 'nextpage', 'url': nextpage, 'thumbnail': 'DefaultFolder.png'})
    return resultsList

def GetStreamUrl(url):
    #skipAd
    print url
    if 'clkme.in' in url:
        url=cllkme(url)
    elif 'clkmein.com' in url:
        url = clkmein(url)
    elif 'sh.st' in url:
        url=sh(url)
    elif 'adf.ly' in url:
        url = adfly(url)
    elif 'viid.me' in url:
        url=viid(url)
    elif 'wiid.me' in url:
        url=viid(url)
    print url

    #playurl
    if ".m3u8" in url:
        return url

    elif "dailymotion" in url:
        id = (url.strip("http://www.dailymotion.com/embed/video/")).split("?")[0]
        return "plugin://plugin.video.dailymotion_com/?url=%s&mode=playVideo"%(id),"dailymotion"

    elif "wistia" in url:
        regex = r"https?://(embed-ssl\.wistia\.com)/(deliveries)/(\w+).(bin)"
        r = requests.get(url)
        r.encoding = 'utf-8'
        soup = BeautifulSoup(r.text, 'html5lib')
        wistia = soup.findAll('script')
        wistialist = str(wistia[2])
        return "https://embedwistia-a.akamaihd.net/deliveries/%s/file.mp4" % (re.findall(regex, wistialist)[0][2])

    elif "youtube" in url:
        regex = r"^http://www.youtube.com/embed\/(.*)\?version"
        return "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=%s"% (re.findall(regex, url)[0]),"youtube"

    elif "myfile.co.il"  in url:
        return myfile(url)

    elif "upf.co.il" in url or "upfile.co.il" in url:
        return upf(url)

    else:
        try:
            media_url = urlresolver.resolve(url)
            if media_url:
                return media_url,"Movie"
            else:
                return "404","Error"
        except:
            return "404", "Error"

